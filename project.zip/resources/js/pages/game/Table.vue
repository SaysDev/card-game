<script setup lang="ts">
import GameBoard from '@/components/game/GameBoard.vue'; // Zmieniamy na GameBoard
</script>

<template>
    <div id="app">
        <game-board />
    </div>
</template>

<style>

body {
    font-family: 'Inter', sans-serif;
    margin: 0;
    padding: 0;
}
</style>
